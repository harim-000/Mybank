create
    definer = root@`%` function get_tree_wikictegry(value int) returns int reads sql data
BEGIN
    DECLARE _parent INT;
    DECLARE _rank INT;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET @id = NULL;

    SET _parent = @id;
    SET _rank = 0;

    IF @id IS NULL THEN
        RETURN NULL;
    END IF;

    LOOP
      SET @innerrank = 0;
      SELECT p.wiki_ctegry_seq
        INTO @id
        FROM (
             SELECT wiki_ctegry_seq
                  , @innerrank := @innerrank+1 AS ran
               FROM tbbs_wiki_ctegry
              WHERE COALESCE(up_wiki_ctegry_seq, 0) = _parent
           ORDER BY srt_seq
             ) p
       WHERE p.ran > _rank LIMIT 0, 1;
      IF @id IS NOT NULL OR _parent = @start_with THEN
          SET @level = @level + 1;
          RETURN @id;
      END IF;
      SET @level := @level - 1;
      SET @innerrank = 0;
      SELECT COALESCE(p.up_wiki_ctegry_seq, 0)
           , p.ran
        INTO _parent
           , _rank
        FROM (
             SELECT wiki_ctegry_seq
                  , up_wiki_ctegry_seq
                  , @innerrank := @innerrank+1 AS ran
               FROM tbbs_wiki_ctegry
              WHERE COALESCE(up_wiki_ctegry_seq, 0) = (
                                                 SELECT COALESCE(up_wiki_ctegry_seq, 0) 
                                                   FROM tbbs_wiki_ctegry 
                                                  WHERE wiki_ctegry_seq = _parent
                                                )
           ORDER BY srt_seq
             ) p
       WHERE p.wiki_ctegry_seq = _parent;
    END LOOP;
END;

