create
    definer = root@`%` function get_tree_wikicte(value int) returns int reads sql data
BEGIN
    DECLARE _parent INT;
    DECLARE _rank INT;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET @id = NULL;

    SET _parent = @id;
    SET _rank = 0;

    IF @id IS NULL THEN
      RETURN NULL;
    END IF;

    LOOP
      SET @innerrank = 0;
      SELECT CAST(p.ctegry_cd AS UNSIGNED)
          INTO   @id
      FROM   (
             SELECT   wiki_ctegry_seq, @innerrank := @innerrank+1 AS ran
             FROM     tbbs_wiki_ctegry
             WHERE    COALESCE(CAST(up_wiki_ctegry_seq AS UNSIGNED), 0) = _parent
             ORDER BY srt_seq
             ) p
      WHERE   p.ran > _rank LIMIT 0, 1;
      IF @id IS NOT NULL OR _parent = @start_with THEN
        SET @level = @level + 1;
        RETURN @id;
      END IF;
      SET @level := @level - 1;
      SET @innerrank = 0;
      SELECT COALESCE(CAST(p.up_wiki_ctegry_seq AS UNSIGNED), 0), p.ran
          INTO   _parent, _rank
      FROM   (
             SELECT CAST(wiki_ctegry_seq AS UNSIGNED) as wiki_ctegry_seq
                  , CAST(up_wiki_ctegry_seq AS UNSIGNED) as up_wiki_ctegry_seq
                  , @innerrank := @innerrank+1 AS ran
             FROM    tbbs_wiki_ctegry
             WHERE   COALESCE(CAST(up_wiki_ctegry_seq AS UNSIGNED), 0) = (
                                           SELECT COALESCE(CAST(up_wiki_ctegry_seq AS UNSIGNED), 0) FROM tbbs_wiki_ctegry WHERE CAST(wiki_ctegry_seq AS UNSIGNED) = _parent
                                           )
             ORDER BY srt_seq
             ) p
      WHERE CAST(p.wiki_ctegry_seq AS UNSIGNED) = _parent;
    END LOOP;
  END;

