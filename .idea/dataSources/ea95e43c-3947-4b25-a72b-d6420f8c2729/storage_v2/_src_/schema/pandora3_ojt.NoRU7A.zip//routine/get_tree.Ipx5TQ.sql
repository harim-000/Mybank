create
    definer = root@`%` function get_tree(val int) returns varchar(50)
BEGIN

        DECLARE _code  int;

        DECLARE _parent int;

        DECLARE CONTINUE HANDLER FOR NOT FOUND SET @code = NULL;



        SET _parent = @code;

        SET _code = 0;

        

        IF @code IS NULL THEN

                RETURN NULL;

        END IF;



       LOOP

		 SELECT min(MNU_SEQ)

		 INTO @code 

		 FROM    TSYS_ADM_MNU

		 WHERE  FRNT_YN='N'

		   AND  UP_MNU_SEQ = _parent

		   AND  MNU_SEQ > _code 
		   

	        ;

		   

        IF @code IS NOT NULL OR _parent = @start_with THEN

               SET @level = @level + 1;

               RETURN @code;

        END IF;

        SET @level := @level - 1;

       

        SELECT  MNU_SEQ, UP_MNU_SEQ

        INTO    _code, _parent

        FROM    TSYS_ADM_MNU

        WHERE   MNU_SEQ = _parent

          AND   FRNT_YN='N'

         ;

       END LOOP;

END;

