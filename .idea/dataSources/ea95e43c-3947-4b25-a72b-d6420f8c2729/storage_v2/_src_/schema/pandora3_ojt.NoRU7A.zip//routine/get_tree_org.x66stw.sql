create
    definer = root@`%` function get_tree_org(val int) returns varchar(50)
BEGIN

	DECLARE _code	INT;

	DECLARE _parent	INT;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @code = NULL;



	SET _parent = @code;

	SET _code = 0;

 

	IF @code IS NULL THEN

		RETURN NULL;

	END IF;



	LOOP

		SELECT min(LPAD(ORG_CD, 10, '0'))

		  INTO @code 

		  FROM TSYS_ORG

		 WHERE LPAD(UP_ORG_CD, 10, '0') = _parent

		   AND LPAD(ORG_CD, 10, '0') > _code 

		;

   

		IF @code IS NOT NULL OR _parent = @start_with THEN

			SET @level = @level + 1;

			RETURN @code;

		END IF;

		

		SET @level := @level - 1;

 

		SELECT LPAD(ORG_CD, 10, '0')

			 , LPAD(UP_ORG_CD, 10, '0')

		  INTO _code

			 , _parent

		  FROM TSYS_ORG

		 WHERE LPAD(ORG_CD, 10, '0') = _parent

		;

	END LOOP;

END;

