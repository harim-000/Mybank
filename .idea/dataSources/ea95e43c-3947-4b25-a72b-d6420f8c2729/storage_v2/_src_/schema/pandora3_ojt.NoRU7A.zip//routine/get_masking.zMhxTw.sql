create
    definer = root@`%` function get_masking(inputTxt varchar(300), maskingType varchar(300)) returns varchar(300)
BEGIN
     DECLARE returnVal  VARCHAR(300);
         SET returnVal = "-";
 
     
     IF 'name'= maskingType THEN
         SELECT CASE WHEN inputTxt IS NULL 
                     THEN '-'
                     WHEN CHAR_LENGTH(inputTxt) < 3
                     THEN CONCAT(SUBSTR(inputTxt, 1, CHAR_LENGTH(inputTxt) -1), LPAD('*', 1, '*'))
                     ELSE CONCAT(SUBSTRING(inputTxt, 1, 1) ,LPAD('*', CHAR_LENGTH(inputTxt) - 2, '*'), SUBSTRING(inputTxt, CHAR_LENGTH(inputTxt), CHAR_LENGTH(inputTxt)))
                 END val
           INTO returnVal;
   
     END IF;
     
     IF 'email'= maskingType THEN
         SELECT CASE WHEN inputTxt IS NULL 
                     THEN '-'
                     ELSE CONCAT(
										  SUBSTR(inputTxt, 1, 1)
										, LPAD('*',CHAR_LENGTH( SUBSTR(inputTxt,1,INSTR(inputTxt,"@")-1))-2, '*')
										, SUBSTR(inputTxt, CHAR_LENGTH(SUBSTR(inputTxt,1,INSTR(inputTxt,"@")-1))))
                 END val
           INTO returnVal;
   
     END IF;
     
     IF 'lgn_id'= maskingType THEN
         SELECT CASE WHEN inputTxt IS NULL 
                     THEN '-'
                     WHEN CHAR_LENGTH(inputTxt) < 4 
                     THEN CONCAT(SUBSTR(inputTxt, 1, CHAR_LENGTH(inputTxt) -1), LPAD('*', 1, '*'))
                     ELSE CONCAT(SUBSTR(inputTxt, 1, CHAR_LENGTH(inputTxt) -3), LPAD('*', 3, '*'))
                 END val
           INTO returnVal;
   
     END IF;
                    
      RETURN returnVal;
END;

