create
    definer = root@`%` function get_tree_wiki(val int) returns varchar(50)
BEGIN
	DECLARE _code  int;
	DECLARE _parent int;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @code = NULL;

	SET _parent = @code;
	SET _code = 0;
	IF @code IS NULL THEN
			RETURN NULL;
	END IF;

	LOOP
		SELECT min(wiki_ctegry_seq)
		  INTO @code 
		  FROM tbbs_wiki_ctegry
		 WHERE 1=1
		   AND up_wiki_ctegry_seq = _parent
		   AND wiki_ctegry_seq > _code 
		;

		IF (@code IS NOT NULL OR _parent = @start_with) 
			THEN SET @level = @level + 1;
			RETURN @code;
		END IF;

		SET @level := @level - 1;

		SELECT wiki_ctegry_seq, up_wiki_ctegry_seq
		  INTO _code, _parent
		  FROM tbbs_wiki_ctegry
		 WHERE wiki_ctegry_seq = _parent
		;

	END LOOP;
end;

